#!/bin/bash
echo enable-uart2 > /sys/devices/bone_capemgr.9/slots
echo enable-uart3 > /sys/devices/bone_capemgr.9/slots
echo enable-uart5 > /sys/devices/bone_capemgr.9/slots

#!/bin/bash
echo BB-UART4 > /sys/devices/bone_capemgr.9/slots
echo BB-UART2 > /sys/devices/bone_capemgr.9/slots
echo BB-UART1 > /sys/devices/bone_capemgr.9/slots


#!/bin/sh


for ((i =1; i <= 10; i++))
do

	python /home/pi/oddBrain/oddBrain.py
	sleep 1
done

